package com.example.cropconnoisseur;

public class YouTubeConfig {

    public YouTubeConfig() {
    }

    public static final String API_KEY = "YOUR API KEY";

    public static String getApiKey() {
        return API_KEY;
    }
}
