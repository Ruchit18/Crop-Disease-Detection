package com.example.cropconnoisseur.Notifications;

public class MyResponse {

    public int success;

}
