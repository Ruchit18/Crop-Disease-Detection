package com.example.cropconnoisseur.Model;

public class Rain {

    public double rain;

}
