package com.example.cropconnoisseur.Model;

public class Test {
    public String testColor;
    public String testComment;

    public Test() {
    }

    public Test(String testColor, String testComment) {
        this.testColor = testColor;
        this.testComment = testComment;
    }

    public String getTestColor() {
        return testColor;
    }

    public void setTestColor(String testColor) {
        this.testColor = testColor;
    }

    public String getTestComment() {
        return testComment;
    }

    public void setTestComment(String testComment) {
        this.testComment = testComment;
    }
}
